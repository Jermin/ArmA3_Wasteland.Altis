*Wasteland.Altis* by Team Wasteland!
===================

ArmA 3 Wasteland is a harsh survival sandbox mission where 2 teams and independent players fight for survival.


The mission is not ready yet, so for now it's just a placeholder :)


*Team Wasteland* collaborators:

       GoT - JoSchaap
       TPG - AgentRev
           - MercyfulFate
       KoS - His_Shadow
       KoS - Bewilderbeest
       404 - Del1te
