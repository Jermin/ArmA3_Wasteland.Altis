#define strM(x) ([x, ","] call format_integer)
