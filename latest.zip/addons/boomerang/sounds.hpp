#include "sound_constants.h"
SOUND(contact_voice,PATH(contact.ogg));
SOUND(contact_beep,PATH(beep.ogg));
SOUND(at_1,PATH(1.ogg));
SOUND(at_2,PATH(2.ogg));
SOUND(at_3,PATH(3.ogg));
SOUND(at_4,PATH(4.ogg));
SOUND(at_5,PATH(5.ogg));
SOUND(at_6,PATH(6.ogg));
SOUND(at_7,PATH(7.ogg));
SOUND(at_8,PATH(8.ogg));
SOUND(at_9,PATH(9.ogg));
SOUND(at_10,PATH(10.ogg));
SOUND(at_11,PATH(11.ogg));
SOUND(at_12,PATH(12.ogg));


