
class CfgSounds
{
	sounds[] = 
	{
		beep, beep2, beep3, beep4, beep5, beep6, beep7, beep8, beep9
	};
		class beep
			{
                                sound[] = {"addons\beacondetector\sound\beep.wav", db-10, 0.5};
                                titles[] = {};
			};		
		class beep2
			{
                                sound[] = {"addons\beacondetector\sound\beep.wav", db-10, 0.6};
                                titles[] = {};
			};
		class beep3
			{
                                sound[] = {"addons\beacondetector\sound\beep.wav", db-10, 0.7};
                                titles[] = {};
			};
		class beep4
			{
                                sound[] = {"addons\beacondetector\sound\beep.wav", db-10, 0.8};
                                titles[] = {};
			};
		class beep5
			{
                                sound[] = {"addons\beacondetector\sound\beep.wav", db-10, 0.9};
                                titles[] = {};
			};
		class beep6
			{
                                sound[] = {"addons\beacondetector\sound\beep.wav", db-10, 1.0};
                                titles[] = {};
			};
		class beep7
			{
                                sound[] = {"addons\beacondetector\sound\beep.wav", db-10, 1.2};
                                titles[] = {};
			};
		class beep8
			{
                                sound[] = {"addons\beacondetector\sound\beep.wav", db-10, 1.4};
                                titles[] = {};
			};
		class beep9
			{
                                sound[] = {"addons\beacondetector\sound\beep.wav", db-10, 0.1};
                                titles[] = {};
			};
		

};
